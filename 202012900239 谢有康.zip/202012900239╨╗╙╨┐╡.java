import java.util.*;
        import java.awt.*;
        import javax.swing.*;
        import java.awt.event.*;

class Calculator extends JFrame implements ActionListener{

    String[] KEYS = {"7","8","9","/","4","5","6","*","1","2","3","-",".","0","+","=","sqr","e","Π","c"};
    JButton jb[] = new JButton[KEYS.length];
    JTextField resultText = new JTextField("0");//结果文本框
    String b="";
    Font font = new Font("微软雅黑",Font.BOLD,30);

    public Calculator(){//构造函数
        super("计算器");
        //创建容器
        Container c = this.getContentPane();
        c.setLayout(new GridLayout(6,1));
        JPanel ButtonPanel1 = new JPanel(new GridLayout(1,4));//按键容器
        JPanel ButtonPanel2 = new JPanel(new GridLayout(1,4));//按键容器
        JPanel ButtonPanel3 = new JPanel(new GridLayout(1,4));//按键容器
        JPanel ButtonPanel4 = new JPanel(new GridLayout(1,4));//按键容器
        JPanel ButtonPanel5 = new JPanel(new GridLayout(1,4));

        //组件设置
        resultText.setEditable(false);//文本框不可编辑
        resultText.setHorizontalAlignment(JTextField.RIGHT);//文本框内容右对齐
        resultText.setFont(font);

        for(int i=0;i<KEYS.length;i++){
            jb[i]=new JButton(KEYS[i]);
        }

        //添加组件到容器
        for(int i=0;i<4;i++){
            ButtonPanel1.add(jb[i]);
        }
        for(int i=4;i<8;i++){
            ButtonPanel2.add(jb[i]);
        }
        for(int i=8;i<12;i++){
            ButtonPanel3.add(jb[i]);
        }
        for(int i=12;i<16;i++){
            ButtonPanel4.add(jb[i]);
        }
        for(int i=16;i<20;i++){
            ButtonPanel5.add(jb[i]);
        }
        c.add(resultText);
        c.add(ButtonPanel5);
        c.add(ButtonPanel1);
        c.add(ButtonPanel2);
        c.add(ButtonPanel3);
        c.add(ButtonPanel4);

        //注册事件到监听器
        for(int i=0;i<20;i++){
            jb[i].addActionListener(this);
        }

        //可见和大小
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500,650);
        this.setVisible(true);

    }

    /******中缀表达式转换为后缀表达式******/
    String[] yunsuan(String strmiddle){	//str中缀表达式
        String s = "";
        Stack<String> sta = new Stack<String>();//创建一个空堆栈
        int j=0;
        String jieguo[] = new String[100];//后缀表达式
        for(int i=0;i<strmiddle.length();i++){
            if("0123456789.".indexOf(strmiddle.charAt(i))>=0){//如果是数字
                s = "";
                for(;i<strmiddle.length()&&"0123456789.".indexOf(strmiddle.charAt(i))>=0;i++){
                    s+=strmiddle.charAt(i);
                }
                i--;jieguo[j]=s;j++;	//数字直接输出
            }
            else if("*/".indexOf(strmiddle.charAt(i))>=0){//高优先级运算符
                if(sta.empty()) //如果栈为空直接入栈
                    sta.push(strmiddle.charAt(i)+"");
                else{//栈不为空
                    if("*/".indexOf(sta.peek())>=0){//栈顶为同级运算符
                        jieguo[i] = sta.pop();j++;
                        sta.push(strmiddle.charAt(i)+"");
                    }
                    else{//低优先级运算符
                        sta.push(strmiddle.charAt(i)+"");
                    }
                }
            }
            else if("+-".indexOf(strmiddle.charAt(i))>=0){//遇到低优先级运算符
                if(sta.empty()) //如果栈为空直接入栈
                    sta.push(strmiddle.charAt(i)+"");
                else{//栈不为空，无论栈顶是高优先级还是低优先级都是先弹出再入栈
                    jieguo[i] = sta.pop();j++;
                    sta.push(strmiddle.charAt(i)+"");
                }
            }
        }
        while(!sta.empty()){
            jieguo[j]=sta.pop();j++;
        }
        return jieguo;
    }

    /******计算后缀表达式结果******/
    String Result(String strlast[]){
        Stack<String> sta = new Stack<String>();
        for(int i=0;strlast[i]!=null;i++){
            if("+-/*".indexOf(strlast[i])<0){//遇到数字进栈
                sta.push(strlast[i]);
            }
            else{//遇到运算符
                double num1,num2,ans=0;
                num1 = Double.parseDouble(sta.pop());
                num2 = Double.parseDouble(sta.pop());
                if("-".indexOf(strlast[i])>=0) ans=num2-num1;
                if("+".indexOf(strlast[i])>=0) ans=num2+num1;
                if("*".indexOf(strlast[i])>=0) ans=num2*num1;
                if("/".indexOf(strlast[i])>=0){
                    if(num1==0){
                        String s="ERROR";
                        return s;
                    }
                    else ans=num2/num1;
                }
                sta.push(String.valueOf(ans));//结果重新入栈
            }
        }
        return sta.pop();
    }

    /******处理事件******/
    public void actionPerformed(ActionEvent e){
        String label = e.getActionCommand();//获得事件源的标签

        if(label=="="||label=="c"){
            if(label=="="){					//显示结果
                String s[]=yunsuan(this.b);
                String result=Result(s);
                this.b=result+"";
                resultText.setText(this.b);//更新文本框
            }
            else {
                this.b ="";
                resultText.setText("");	//清零
            }
        }
        else if(label=="sqr"){
            String n=yunsuan2(this.b);
            resultText.setText(n);
            this.b=n;
        }
        else if(label=="e"||label=="Π"){
            if(label=="e") {String m=String.valueOf(2.71828);this.b+=m;}
            else {String m=String.valueOf(3.14159265);this.b+=m;}
            resultText.setText(this.b);
        }
        else {
            this.b+=label;
            resultText.setText(this.b);
        }
    }

    /*开方运算*/
    String yunsuan2(String str){
        double a = Double.parseDouble(str),b=0;
        b = Math.sqrt(a);
        return String.valueOf(b);
    }
    public static void main(String args[]){
        Calculator mycalculate = new Calculator();
    }
}

