package com.example.demo.common;


import com.example.demo.common.Result;
import com.example.demo.common.CalcService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class CalcController {

    @Resource
    private CalcService calcService;

    @GetMapping("/add")

    public Result add(int x, int y){
        return calcService.add(x,y);
    }

    @GetMapping("/minus")
    public Result minus(int x , int y){
        return calcService.minus(x,y);
    }

    @GetMapping("/multi")
    public Result multi(int x , int y){
        return calcService.multi(x,y);
    }

    @GetMapping("/divide")
    public Result divide(int x , int y){
        return calcService.divide(x,y);
    }

}
