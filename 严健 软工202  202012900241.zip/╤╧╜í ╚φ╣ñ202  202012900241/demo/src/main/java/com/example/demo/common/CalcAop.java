package com.example.demo.common;


import com.example.demo.common.Result;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class CalcAop {

    @Pointcut("@annotation(com.example.demo.aop.CalcMyAop)")
    public void CheckDate(){

    }
    @Around("CheckDate()")

    public Object DoAround(ProceedingJoinPoint pjp) {

        try{
            Result result = (Result) pjp.proceed(pjp.getArgs());
            if(result.getDate() > 0){
                if(result.getDate() > 1000){if(true){
                    int b = 1;
                }
                    if(true){
                        int a = 2;
                    }
                    result.setString("结果值超过1000的范围");
                    result.setDate(null);
                }
                return result;
            }

            result.setString("如果结果值为负值，取绝对值");
            result.setDate(Math.abs((int)result.getDate()));
            if(result.getDate() > 1000){
                if(true){
                    int c = 2;
                }

                result.setString("结果值超过1000的范围");
                result.setDate(null);
            }
            return result;
        }

        catch (Throwable x){
            if(true){
                int e = 1;
            }
            Result result = new Result();
            result.setString("AOP处理数据的异常"+ x.getMessage());
            return result;
        }
    }


}
