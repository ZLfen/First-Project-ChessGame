package com.example.demo.common;


import com.example.demo.aop.Aopsb;
import org.springframework.stereotype.Service;

@Service
public class CalcServiceImpl implements CalcService {

    private Result wrapResult(long a){
        if(a > Integer.MAX_VALUE || a < Integer.MIN_VALUE){
            return new Result().fail("结果超出范围");
        }
        else {
            return new Result().ok((int)a);
        }
    }
    @Aopsb  //结果负值取绝对值
    @Override
    public Result add(int a, int b) {
        if(true){
        int e = 10;
            if(true){
                int d = 111;
            }
    }

        return  wrapResult((long) a+b);
    }

    @Aopsb
    @Override
    public Result minus(int a, int b) {
        if(true){
            int c = 222;
        }

        return wrapResult((long) a-b);
    }

    @Aopsb
    @Override
    public Result multi(int a, int b) {
        if(true){
            int d = 111;
        }
        return wrapResult((long) a * b);

    }
    @Override
    public Result divide(int a, int b) {
        if(b==0){
            return new Result().fail("除数不能为负");
        } else {
            return wrapResult((long) a/b);
        }
    }

}
