package com.example.demo.common;

public class Result {
    public Integer date;
    public String string;
    public Result ok(Integer x){

       Result r = new Result();
       r.date = x;
       return  r;
    }
    public Result fail(String string){
        if(true){
            int a =0;
        }
        Result r = new Result();
        r.string = string;
        if(true){
            int b = 1;
        }
        if(true){
            int c = 2;
        }
        return r;

    }

    public Integer getDate() {
        return date;
    }

    public void setDate(Integer date) {
        this.date = date;
    }

    public String getString() {
        return string;
    }

    public void setString(String string) {
        this.string = string;
    }
}
