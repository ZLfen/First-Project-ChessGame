package wuziqi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class DrawPanel extends JPanel implements MouseListener {
    public static final int row=15;
    public static final int col=15;
    public static final int margin=30;//边距
    public static final int grid=35;//棋格内距
    int x_index;
    int y_index;
    private boolean isBlack=true;
    public int count=0;
    public boolean gameover=false;


    public chess[] chesslist=new chess[(row+1)*(col+1)];


    public DrawPanel(){
        this.setBackground(Color.pink);
        this.addMouseListener(this);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        for(int i=0;i<=row;i++){//引用for循环重画之前的棋子
            g.drawLine(margin,margin+grid*i,margin+grid*col,margin+grid*i);
        }
        for(int j=0;j<=col;j++){
            g.drawLine(margin+grid*j,margin,margin+grid*j,margin+grid*row);
        }
        for(int i=0;i<count;i++){
            //System.out.println(" "+count);
            int xt=chesslist[i].getX()*grid+margin;
            int yt=chesslist[i].getY()*grid+margin;
            g.setColor(chesslist[i].getColor());
            g.fillOval(xt-chess.chess_space/2,yt-chess.chess_space/2,chess.chess_space,chess.chess_space);
            if(i==count-1){
                g.setColor(Color.red);
                g.drawRect(xt-chess.chess_space/2,yt-chess.chess_space/2,chess.chess_space,chess.chess_space);
            }//设置当前棋子的选中框
        }



    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(margin*2+grid*row,margin*2+grid*col);//设置当前组件的显示大小
    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        x_index=(e.getX()-margin+grid/2)/grid;//获取索引值
        y_index=(e.getY()-margin+grid/2)/grid;
        System.out.println("("+x_index+","+y_index+")");

        if(gameover)//判断游戏是否结束
            return ;

        if(x_index<0||x_index>col||y_index<0||y_index>row)//判断是否出界
            return;

        if(findchess(x_index,y_index)){//判断下的棋子是否重合
            return;

        }


        chess c=new chess(x_index,y_index,isBlack?Color.black:Color.white);
        chesslist[count++]=c;
        System.out.println("棋子个数: "+count);
        this.repaint();

        if(iswin()){
            String s=String.format("恭喜%s赢得比赛",isBlack?"黑方":"白方");
            JOptionPane.showMessageDialog(this,s);//弹出对话框
            gameover=true;

        }//判断输赢

        isBlack=!isBlack;//换方


    }

    public boolean iswin(){
        if(search1()||search2()||search3()||search4()){
            return true;
        }
        return false;
    }

    public boolean findchess(int x,int y){
        for(chess c:chesslist){
            if(c!=null&&c.getX()==x&&c.getY()==y){
                return true;
            }
        }
        return false;
    }

    public chess findchess1(int x,int y,Color color){//找棋子，判断是否五子连珠
        for(chess c:chesslist){
            if(c!=null&&c.getX()==x&&c.getY()==y&&c.getColor()==color){
                return c;
            }
        }
        return null;
    }


    //从不同方向判断五子连珠
    public boolean search1() {
        int continuechess = 1;
        for (int x = x_index + 1, y = y_index - 1; x <= col && y >= 0; x++, y--) {
            Color color = isBlack ? Color.black : Color.white;
            if (findchess1(x, y, color) != null) {
                continuechess++;
            } else break;
        }//东北方向（斜上）

        for (int x = x_index - 1, y = y_index + 1; y <= row && x >= 0; y++, x--) {
            Color color = isBlack ? Color.black : Color.white;
            if (findchess1(x, y, color) != null) {
                continuechess++;
            } else break;
        }//东北方向（斜下）
        if(continuechess>=5)
            return true;
        else continuechess=1;
        return false;
    }


    public boolean search2() {
        int continuechess=1;
        for (int x = x_index - 1, y = y_index - 1; y >= 0 && x >= 0; y--, x--) {
            Color color = isBlack ? Color.black : Color.white;
            if (findchess1(x, y, color) != null) {
                continuechess++;
            } else break;
        }//东南方向（斜上）

        for (int x = x_index + 1, y = y_index + 1; y <= row && x <= col; y++, x++) {
            Color color = isBlack ? Color.black : Color.white;
            if (findchess1(x, y, color) != null) {
                continuechess++;
            } else break;
        }//东南方向（斜下）
        if(continuechess>=5)
            return true;
        else continuechess=1;
        return false;
    }

    public boolean search3() {
        int continuechess=1;
        for (int y = y_index - 1; y >= 0; y--) {
            Color color = isBlack ? Color.black : Color.white;
            if (findchess1(x_index, y, color) != null) {
                continuechess++;
            } else break;
        }//北方向

        for (int y = y_index + 1; y >= 0; y++) {
            Color color = isBlack ? Color.black : Color.white;
            if (findchess1(x_index, y, color) != null) {
                continuechess++;
            } else break;
        }//南方向
        if(continuechess>=5)
            return true;
        else continuechess=1;
        return false;
    }

    public boolean search4() {
        int continuechess=1;
        for (int x = x_index + 1; x <= col; x++) {
            Color color = isBlack ? Color.black : Color.white;
            if (findchess1(x, y_index, color) != null) {
                continuechess++;
            } else break;
        }//东方向

        for (int x = x_index - 1; x >= 0; x--) {
            Color color = isBlack ? Color.black : Color.white;
            if (findchess1(x, y_index, color) != null) {
                continuechess++;
            } else break;
        }//西方向
        if(continuechess>=5)
            return true;
        else continuechess=1;
        return false;
    }

    public void restart(){//重新开始
        for (int i = 0; i <chesslist.length ; i++) {
            chesslist[i]=null;
        }
        isBlack=true;
        gameover=false;
        count=0;
        this.repaint();
    }

    public void reback(){//悔棋
        if(count==0){
            return;
        }
        chesslist[count-1]=null;
        count--;
        if(count>0){
            x_index=chesslist[count-1].getX();
            y_index=chesslist[count-1].getY();
        }
        isBlack=!isBlack;
        this.repaint();
    }


    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
