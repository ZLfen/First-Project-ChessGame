package wuziqi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class MyFrame extends JFrame {
    public static final int wide=300;
    public static final int height=400;
    DrawPanel drawPanel=new DrawPanel();
    JPanel tool=new JPanel();//添加一个工具栏面板
    JMenuBar menuBar=new JMenuBar();//菜单栏
    JMenu menu=new JMenu("系统");//菜单
    JMenuItem item1=new JMenuItem("开始");
    JMenuItem item2=new JMenuItem("悔棋");
    JMenuItem item3=new JMenuItem("结束");//设置三个菜单项
    JButton j1=new JButton("开始");
    JButton j2=new JButton("悔棋");
    JButton j3=new JButton("退出");



    public MyFrame(){
        Mylistener mylistener=new Mylistener();
        this.setTitle("五子棋");
        this.setSize(wide,height);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(drawPanel, BorderLayout.CENTER);
        item1.addActionListener(mylistener);
        item2.addActionListener(mylistener);
        item3.addActionListener(mylistener);
        this.setJMenuBar(menuBar);//设置菜单条
        menuBar.add(menu);//在菜单栏中添加菜单
        menu.add(item1);
        menu.add(item2);
        menu.add(item3);//在菜单中添加菜单项
        j1.addActionListener(mylistener);
        j2.addActionListener(mylistener);
        j3.addActionListener(mylistener);
        tool.add(j1);
        tool.add(j2);
        tool.add(j3);
        this.add(tool,BorderLayout.NORTH);
        this.setLocation((Toolkit.getDefaultToolkit().getScreenSize().width)/2-200,(Toolkit.getDefaultToolkit().getScreenSize().height)/2-300);
        //使得打开的窗口适中
        pack();//使得窗口里组件包紧
        this.setVisible(true);

    }
    public class Mylistener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource()==j1||e.getSource()==item1){  //获得按钮和菜单栏这两个对象,并执行其应对应的方法
                drawPanel.restart();
            }
            if(e.getSource()==j2||e.getSource()==item2){
                drawPanel.reback();
            }
            if(e.getSource()==j3||e.getSource()==item3)
                System.exit(0);
        }
    }



}
