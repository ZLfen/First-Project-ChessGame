package wuziqi;

public class Test {
    public static void main(String[] args) {
        new MyFrame();
    }
}
