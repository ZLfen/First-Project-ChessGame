package wuziqi;

import java.awt.*;

public class chess {
    public int x;
    public int y;


    public Color color;
    public static final int chess_space=30;//棋子直径



    public chess(int x, int y, Color color){
        this.x=x;
        this.y=y;
        this.color=color;

    }

    public void setColor(Color color) {
        this.color = color;
    }


    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Color getColor() {
        return color;
    }


}
